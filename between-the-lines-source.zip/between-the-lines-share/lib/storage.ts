type AppEnv = {
  DB: D1Database;
  LESSON_FILES: R2Bucket;
  OPENAI_API_KEY?: string;
  OPENAI_MODEL?: string;
};

export async function getEnv() {
  const { env } = await import("cloudflare:workers");
  return env as unknown as AppEnv;
}

const schema = [
  `CREATE TABLE IF NOT EXISTS lessons (
    id TEXT PRIMARY KEY,
    user_email TEXT NOT NULL,
    title TEXT NOT NULL,
    file_key TEXT,
    file_name TEXT,
    content_text TEXT NOT NULL DEFAULT '',
    topics_json TEXT NOT NULL DEFAULT '[]',
    items_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE INDEX IF NOT EXISTS lessons_user_created ON lessons(user_email, created_at DESC)`,
  `CREATE TABLE IF NOT EXISTS mistakes (
    id TEXT PRIMARY KEY,
    user_email TEXT NOT NULL,
    lesson_id TEXT,
    prompt TEXT NOT NULL,
    user_answer TEXT NOT NULL,
    model_answer TEXT NOT NULL DEFAULT '',
    tags_json TEXT NOT NULL DEFAULT '[]',
    note TEXT NOT NULL DEFAULT '',
    interval_days INTEGER NOT NULL DEFAULT 1,
    repetitions INTEGER NOT NULL DEFAULT 0,
    next_review_at TEXT NOT NULL,
    mastered INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE INDEX IF NOT EXISTS mistakes_user_due ON mistakes(user_email, mastered, next_review_at)`,
  `CREATE TABLE IF NOT EXISTS attempts (
    id TEXT PRIMARY KEY,
    user_email TEXT NOT NULL,
    lesson_id TEXT,
    exercise_type TEXT NOT NULL,
    topic TEXT NOT NULL,
    score INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE INDEX IF NOT EXISTS attempts_user_created ON attempts(user_email, created_at DESC)`
];

let initialized = false;

export async function getDb() {
  const env = await getEnv();
  if (!initialized) {
    for (const statement of schema) await env.DB.prepare(statement).run();
    initialized = true;
  }
  return env.DB;
}

export function userEmail(request: Request) {
  return request.headers.get("oai-authenticated-user-email")?.trim().toLowerCase() || "private-owner";
}

export function safeJson<T>(value: unknown, fallback: T): T {
  if (typeof value !== "string") return fallback;
  try { return JSON.parse(value) as T; } catch { return fallback; }
}

export function jsonError(error: unknown, fallback = "Не удалось выполнить запрос") {
  const message = error instanceof Error ? error.message : fallback;
  console.error(message);
  return Response.json({ error: fallback }, { status: 500 });
}
