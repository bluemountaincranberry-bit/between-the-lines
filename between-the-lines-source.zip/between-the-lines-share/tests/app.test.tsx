// @vitest-environment jsdom
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import Home from "@/app/page";

const state = { lessons: [], mistakes: [], attempts: [] };

function response(data: unknown, ok = true) {
  return Promise.resolve({ ok, json: () => Promise.resolve(data) } as Response);
}

describe("practice workflow", () => {
  afterEach(() => vi.restoreAllMocks());

  it("starts a set, checks an answer, and saves a mistake", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockImplementation((input, init) => {
      const url = String(input);
      if (url === "/api/state") return response(state);
      if (url === "/api/feedback") return response({
        source: "local", score: 82, verdict: "Смысл передан хорошо",
        strengths: ["Смысл понятен."], issues: ["Проверьте время."],
        naturalVersion: "I'll call you as soon as I get the results.", explanation: "Короткое объяснение.",
        rules: [{ label: "Time clause", fragment: "as soon as I get", formula: "as soon as + Present Simple", explanation: "После союза времени нужен Present Simple." }]
      });
      if (url === "/api/mistakes") return response({ id: "m1" });
      if (url === "/api/attempts") return response({ ok: true });
      return response({});
    });

    render(<Home />);
    expect(await screen.findByText("Что потренируем сегодня?")).toBeTruthy();
    fireEvent.click(screen.getByText("Свежая B2-практика"));
    const answer = await screen.findByPlaceholderText("Напишите или произнесите ответ…");
    fireEvent.change(answer, { target: { value: "I will call when I get the results." } });
    fireEvent.click(screen.getByText("Проверить ответ"));
    expect(await screen.findByText("Смысл передан хорошо")).toBeTruthy();
    expect(screen.getByText("Разбор по частям: время, конструкция и причина")).toBeTruthy();
    expect(screen.getByText("После союза времени нужен Present Simple.")).toBeTruthy();
    expect(screen.getByPlaceholderText("Почему здесь we've discussed?")).toBeTruthy();
    fireEvent.click(screen.getByText("Сохранить ошибку"));
    await waitFor(() => expect(fetchMock).toHaveBeenCalledWith("/api/mistakes", expect.objectContaining({ method: "POST" })));
  });

  it("opens grammar library and coach filters", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation((input) => {
      if (String(input) === "/api/state") return response(state);
      return response({});
    });
    render(<Home />);
    await screen.findByText("Что потренируем сегодня?");
    fireEvent.click(screen.getAllByText("Грамматика")[0]);
    expect(await screen.findByText("Grammar library")).toBeTruthy();
    fireEvent.click(screen.getAllByText("Практика")[0]);
    fireEvent.click(await screen.findByText("English Coach"));
    expect(await screen.findByText("Что включить в разговор?")).toBeTruthy();
    expect(screen.getByText(/сохранённых ошибок/)).toBeTruthy();
  });
});
