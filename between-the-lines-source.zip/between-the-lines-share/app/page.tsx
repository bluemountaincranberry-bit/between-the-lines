"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleAlert,
  FileText,
  Flame,
  Library,
  LoaderCircle,
  Mic,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Target,
  Trash2,
  Upload,
  Volume2,
  X,
} from "lucide-react";

type LessonItem = { term: string; meaning?: string; example?: string; pronunciation?: string };
type Lesson = {
  id: string;
  title: string;
  fileKey?: string;
  fileName?: string;
  contentText: string;
  topics: string[];
  items: LessonItem[];
  createdAt: string;
};
type Mistake = {
  id: string;
  lessonId?: string;
  prompt: string;
  userAnswer: string;
  modelAnswer: string;
  tags: string[];
  note: string;
  intervalDays: number;
  repetitions: number;
  nextReviewAt: string;
  mastered: boolean;
  createdAt: string;
};
type Attempt = { topic: string; score: number; created_at: string };
type Exercise = {
  id: string;
  lessonId?: string;
  topic: string;
  type: "translation" | "sentence" | "review" | "coach";
  prompt: string;
  modelAnswer: string;
  alternative?: string;
  requiredPhrase?: string;
  targetWords?: string[];
  mistakeId?: string;
};
type Feedback = {
  source: "ai" | "local";
  score: number;
  verdict: string;
  strengths: string[];
  issues: string[];
  naturalVersion: string;
  explanation: string;
  rules?: Array<{ label: string; fragment: string; formula?: string; explanation: string }>;
};

const GRAMMAR: Exercise[] = [
  {
    id: "g1",
    topic: "Conditionals",
    type: "translation",
    prompt: "Если бы ты предупредил меня раньше, я бы успела всё подготовить.",
    modelAnswer:
      "If you had told me earlier, I would have had time to prepare everything.",
    alternative:
      "If you'd let me know earlier, I could have got everything ready.",
  },
  {
    id: "g2",
    topic: "Conditionals",
    type: "translation",
    prompt: "Если ситуация не изменится, нам придётся искать другое решение.",
    modelAnswer:
      "If the situation doesn't change, we'll have to look for another solution.",
  },
  {
    id: "g3",
    topic: "Time clauses",
    type: "translation",
    prompt: "Как только я получу результаты, я тебе позвоню.",
    modelAnswer: "I'll call you as soon as I get the results.",
  },
  {
    id: "g4",
    topic: "Time clauses",
    type: "translation",
    prompt: "Мы не примем окончательное решение, пока не обсудим все варианты.",
    modelAnswer:
      "We won't make a final decision until we've discussed all the options.",
  },
  {
    id: "g5",
    topic: "Modal verbs",
    type: "translation",
    prompt: "Тебе следовало сказать мне об этом раньше.",
    modelAnswer: "You should have told me about it earlier.",
  },
  {
    id: "g6",
    topic: "Modal verbs",
    type: "translation",
    prompt: "Она, должно быть, забыла, что мы договорились встретиться.",
    modelAnswer: "She must have forgotten that we'd arranged to meet.",
  },
  {
    id: "g7",
    topic: "Past tenses",
    type: "translation",
    prompt: "Я шла домой, когда поняла, что оставила ключи в офисе.",
    modelAnswer:
      "I was walking home when I realized I'd left my keys at the office.",
  },
  {
    id: "g8",
    topic: "Past tenses",
    type: "translation",
    prompt: "Пока мы ждали автобус, начался сильный дождь.",
    modelAnswer:
      "While we were waiting for the bus, it started raining heavily.",
  },
  {
    id: "g9",
    topic: "Natural phrasing",
    type: "translation",
    prompt: "Я посмотрю на это внимательнее чуть позже.",
    modelAnswer: "I'll take a closer look at it a bit later.",
    alternative: "I'll have a proper look at it later.",
  },
  {
    id: "g10",
    topic: "Natural phrasing",
    type: "translation",
    prompt:
      "Не думаю, что это что-нибудь сломает, но позже проверю внимательнее.",
    modelAnswer:
      "I don't think it'll break anything, but I'll take a closer look later.",
  },
];
const PATTERNS: Array<[string, RegExp]> = [
  [
    "Conditionals",
    /conditional|if clause|если бы|unless|first conditional|second conditional|third conditional/i,
  ],
  [
    "Time clauses",
    /time clause|as soon as|until|before|after|when clause|временн/i,
  ],
  [
    "Modal verbs",
    /modal|should have|must have|might|could|can’t have|модальн/i,
  ],
  ["Past tenses", /past simple|past continuous|past perfect|прошедш/i],
  [
    "Natural phrasing",
    /collocation|phrasal verb|idiom|everyday|natural english|выражен/i,
  ],
];
const RULES: Record<
  string,
  { title: string; description: string; example: string }[]
> = {
  Conditionals: [
    {
      title: "First conditional",
      description:
        "Реальное или вероятное условие: if + Present Simple, затем will + глагол.",
      example: "If the weather improves, we'll go out.",
    },
    {
      title: "Second conditional",
      description:
        "Воображаемая или маловероятная ситуация: if + Past Simple, затем would + глагол.",
      example: "If I had more time, I'd study every day.",
    },
    {
      title: "Third conditional",
      description:
        "Нереальное прошлое: if + Past Perfect, затем would have + V3.",
      example: "If I'd known, I would have called you.",
    },
  ],
  "Time clauses": [
    {
      title: "Будущее после when / until",
      description:
        "После when, before, after, until и as soon as говорим о будущем в Present Simple, не в will.",
      example: "I'll call you as soon as I get the results.",
    },
  ],
  "Modal verbs": [
    {
      title: "Предположение о прошлом",
      description:
        "Используйте modal + have + V3: must have, might have, can't have.",
      example: "She must have forgotten about the meeting.",
    },
    {
      title: "Совет о прошлом",
      description:
        "Should have + V3 показывает, что раньше стоило поступить иначе.",
      example: "You should have told me earlier.",
    },
  ],
  "Past tenses": [
    {
      title: "Past Simple vs Past Continuous",
      description:
        "Past Continuous задаёт длительный фон, а Past Simple обозначает завершённое событие.",
      example: "I was walking home when it started to rain.",
    },
  ],
  "Natural phrasing": [
    {
      title: "Естественные сочетания",
      description:
        "Запоминайте не отдельное слово, а устойчивое сочетание: make a decision, take a closer look, put something off.",
      example: "I'll take a closer look at it later.",
    },
  ],
  Vocabulary: [
    {
      title: "Учите фразы целиком",
      description:
        "Сохраняйте слово вместе с предлогом, типичным дополнением и одним собственным примером.",
      example: "interested in music · put the meeting off",
    },
  ],
};
const WORD_HELP: Record<string, { meaning: string; example: string }> = {
  "take a closer look": { meaning: "посмотреть внимательнее", example: "I'll take a closer look at it later." },
  "put off": { meaning: "откладывать", example: "We had to put the meeting off until Friday." },
  "make a decision": { meaning: "принять решение", example: "We need to make a decision by tomorrow." },
  "interested in": { meaning: "интересоваться чем-либо", example: "She's always been interested in music." },
  "as soon as": { meaning: "как только", example: "I'll call you as soon as I know the result." },
  "unless": { meaning: "если не", example: "We won't finish on time unless we start now." },
  "should have": { meaning: "следовало бы (о прошлом)", example: "I should have told you earlier." },
  "must have": { meaning: "должно быть (о прошлом)", example: "She must have forgotten about the meeting." },
  "get promoted": { meaning: "получить повышение", example: "He hopes to get promoted this year." },
};
const addKnownHelp=(item:LessonItem):LessonItem=>{const key=item.term.toLowerCase().replace(/^to\s+/,"").trim();const help=WORD_HELP[key];return help?{...help,...item,meaning:item.meaning||help.meaning,example:item.example||help.example}:item};
const COACH_BASE: Exercise[] = [
  {
    id: "c1",
    topic: "Speaking",
    type: "coach",
    prompt:
      "Tell me about something you planned to do recently but had to postpone. What happened?",
    modelAnswer:
      "I was going to finish it on Friday, but something urgent came up, so I had to put it off.",
  },
  {
    id: "c2",
    topic: "Writing",
    type: "coach",
    prompt:
      "Write a short friendly message to a colleague saying you'll take a closer look later.",
    modelAnswer:
      "I'll take a closer look at it later and let you know what I find.",
  },
  {
    id: "c3",
    topic: "Grammar",
    type: "coach",
    prompt:
      "Imagine you missed an important opportunity. What would have happened if you had known about it earlier?",
    modelAnswer:
      "If I'd known about it earlier, I would have prepared properly and applied.",
  },
  {
    id: "c4",
    topic: "Speaking",
    type: "coach",
    prompt:
      "What were you doing the last time something unexpected interrupted you?",
    modelAnswer: "I was working from home when the power suddenly went out.",
  },
  {
    id: "c5",
    topic: "Everyday English",
    type: "coach",
    prompt:
      "Tell me about one thing you should have done differently this week.",
    modelAnswer:
      "I should have gone to bed earlier because I was exhausted the next day.",
  },
];
const shuffle = <T,>(x: T[]) => [...x].sort(() => Math.random() - 0.5);
const formatDate = (x: string) =>
  new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short" }).format(
    new Date(x),
  );
const isDue = (m: Mistake) =>
  !m.mastered && new Date(m.nextReviewAt) <= new Date();
function guided(item: LessonItem, lessonId: string, n: number): Exercise {
  const term = item.term.replace(/^to\s+/i, "");
  const looksVerb =
    /^to\s+/i.test(item.term) ||
    /(ing|ed|ise|ize|fy)$/i.test(term) ||
    term.split(" ").length > 1;
  return looksVerb
    ? {
        id: `guided-${lessonId}-${n}`,
        lessonId,
        topic: "Guided translation",
        type: "translation",
        prompt: `Я постараюсь ${item.meaning || "сделать это"} до конца недели.`,
        modelAnswer: `I'll try to ${term} by the end of the week.`,
        requiredPhrase: term,
        targetWords: [item.term],
      }
    : {
        id: `guided-${lessonId}-${n}`,
        lessonId,
        topic: "Guided translation",
        type: "translation",
        prompt: `На прошлом занятии мы подробно обсуждали ${item.meaning || "эту тему"}.`,
        modelAnswer: `We discussed ${item.term} in detail in the last lesson.`,
        requiredPhrase: item.term,
        targetWords: [item.term],
      };
}

function pronunciationTip(term: string) {
  const tips = ["Нажмите ▶ и повторите фразу целиком в британском ритме."];
  if (/th/i.test(term)) tips.push("В th кончик языка слегка между зубами.");
  if (/r/i.test(term)) tips.push("Британское r обычно не раскатывается и в конце слога почти не звучит.");
  if (/ing\b/i.test(term)) tips.push("Окончание -ing произносится /ɪŋ/, без отдельного g.");
  return tips.join(" ");
}

function analyze(text: string) {
  const clean = text.replace(/\s+/g, " ");
  const topics = PATTERNS.filter(([, p]) => p.test(clean)).map(([t]) => t);
  const items: LessonItem[] = [];
  const seen = new Set<string>();
  for (const raw of text.split(/\n+/)) {
    const line = raw.replace(/\s+/g, " ").trim();
    if (!line) continue;
    const pair = line.match(
      /^([A-Za-z][A-Za-z '\-]{1,60})\s*(?:[-–—:=]|\s{2,})\s*([А-Яа-яЁё][^;]{1,90})$/,
    );
    if (pair && !seen.has(pair[1].toLowerCase())) {
      seen.add(pair[1].toLowerCase());
      items.push({ term: pair[1].trim(), meaning: pair[2].trim() });
    }
    for (const phrase of line.match(
      /\b(?:to\s+)?[a-z]+(?:\s+[a-z]+){1,4}\b/gi,
    ) || []) {
      const term = phrase.trim();
      if (
        term.length > 7 &&
        term.length < 52 &&
        !seen.has(term.toLowerCase()) &&
        items.length < 80
      ) {
        seen.add(term.toLowerCase());
        items.push({ term });
      }
    }
    if (items.length >= 80) break;
  }
  return {
    topics: topics.length ? topics : ["Vocabulary"],
    items: items.slice(0, 60),
  };
}
async function pdfText(file: File) {
  const pdfjs = await import("pdfjs-dist");
  pdfjs.GlobalWorkerOptions.workerSrc =
    "https://cdn.jsdelivr.net/npm/pdfjs-dist@5.4.54/build/pdf.worker.min.mjs";
  const pdf = await pdfjs.getDocument({ data: await file.arrayBuffer() })
    .promise;
  const pages: string[] = [];
  for (let n = 1; n <= Math.min(pdf.numPages, 80); n++) {
    const page = await pdf.getPage(n);
    const content = await page.getTextContent();
    pages.push(content.items.map((i) => ("str" in i ? i.str : "")).join(" "));
  }
  return pages.join("\n");
}

export default function Home() {
  const [view, setView] = useState<"practice" | "lessons" | "grammar" | "review">(
    "practice",
  );
  const [lessons, setLessons] = useState<Lesson[]>([]),
    [mistakes, setMistakes] = useState<Mistake[]>([]),
    [attempts, setAttempts] = useState<Attempt[]>([]);
  const [loading, setLoading] = useState(true),
    [upload, setUpload] = useState(false),
    [selected, setSelected] = useState<Set<string>>(new Set());
  const [studyLesson, setStudyLesson] = useState<Lesson | null>(null);
  const [coachSetup, setCoachSetup] = useState(false);
  const [session, setSession] = useState<Exercise[]>([]),
    [index, setIndex] = useState(0),
    [answer, setAnswer] = useState(""),
    [feedback, setFeedback] = useState<Feedback | null>(null);
  const [checking, setChecking] = useState(false),
    [listening, setListening] = useState(false),
    [toast, setToast] = useState("");
  const recognition = useRef<{ stop: () => void; abort?: () => void } | null>(null);
  const keepListening = useRef(false);
  const speechBase = useRef("");
  const speechCommitted = useRef("");
  const notify = (m: string) => {
    setToast(m);
    window.setTimeout(() => setToast(""), 2100);
  };
  const reload = async () => {
    const r = await fetch("/api/state", { cache: "no-store" });
    if (!r.ok) throw Error();
    const d: any = await r.json();
    setLessons(d.lessons);
    setMistakes(d.mistakes);
    setAttempts(d.attempts);
    setSelected((s) =>
      s.size ? s : new Set(d.lessons.slice(0, 1).map((l: Lesson) => l.id)),
    );
  };
  useEffect(() => {
    reload()
      .catch(() => notify("Не удалось загрузить данные"))
      .finally(() => setLoading(false));
  }, []);
  const stats = useMemo(
    () => ({
      due: mistakes.filter(isDue).length,
      mastered: mistakes.filter((m) => m.mastered).length,
      avg: attempts.length
        ? Math.round(
            attempts.reduce((s, a) => s + Number(a.score), 0) / attempts.length,
          )
        : 0,
    }),
    [mistakes, attempts],
  );
  const current = session[index];

  function start(
    mode: "fresh" | "selected" | "due" | "guided" | "sentence" | "coach",
    forcedIds?: Set<string>,
    forcedTopics?: Set<string>,
  ) {
    let pool: Exercise[] = [];
    if (mode === "due")
      pool = mistakes
        .filter(isDue)
        .map((m) => ({
          id: `r-${m.id}`,
          lessonId: m.lessonId,
          topic: m.tags[0] || "Review",
          type: "review",
          prompt: m.prompt,
          modelAnswer: m.modelAnswer,
          mistakeId: m.id,
        }));
    const chosen = forcedIds || selected;
    const source = ["selected", "guided", "sentence", "coach"].includes(mode) && forcedIds
      ? lessons.filter((l) => chosen.has(l.id))
      : ["selected", "guided", "sentence"].includes(mode)
      ? lessons.filter((l) => chosen.has(l.id))
      : lessons;
    const vocab = source.flatMap((l) =>
      l.items
        .slice(0, 18)
        .map((it, n): Exercise => ({
          id: `v-${l.id}-${n}`,
          lessonId: l.id,
          topic: "Vocabulary",
          type: "sentence",
          prompt: `Составьте естественное английское предложение с выражением “${it.term}”${it.meaning ? ` (${it.meaning})` : ""}.`,
          modelAnswer: `Use “${it.term}” naturally in a complete sentence connected to your experience.`,
          requiredPhrase: it.term,
        })),
    );
    const topics = new Set(source.flatMap((l) => l.topics));
    const grammar = GRAMMAR.filter((g) => !topics.size || topics.has(g.topic));
    const guidedSet = source.flatMap((l) =>
      l.items
        .filter((i) => i.meaning)
        .slice(0, 15)
        .map((item, n) => guided(item, l.id, n)),
    );
    const chosenCoachTopics = forcedTopics || new Set<string>();
    const coachGrammar = chosenCoachTopics.size ? GRAMMAR.filter((g) => chosenCoachTopics.has(g.topic)).map((g) => ({...g, id:`coach-${g.id}`, type:"coach" as const})) : COACH_BASE;
    const coachSet = [
      ...mistakes
        .filter((m) => !m.mastered)
        .slice(0, 2)
        .map((m, n): Exercise => ({
          id: `coach-m-${n}`,
          lessonId: m.lessonId,
          topic: "Your weak point",
          type: "coach",
          prompt: `Let's return to an idea that was difficult before. Answer naturally in English: ${m.prompt}`,
          modelAnswer: m.modelAnswer,
        })),
      ...source.flatMap((l) =>
        l.items
          .slice(0, 5)
          .map((item, n): Exercise => ({
            id: `coach-v-${l.id}-${n}`,
            lessonId: l.id,
            topic: "Lesson conversation",
            type: "coach",
            prompt: `Let's use something from “${l.title}”. Tell me about a real situation where “${item.term}” would fit.`,
            modelAnswer: `Give a complete, natural answer using “${item.term}”.`,
            requiredPhrase: item.term,
            targetWords: [item.term],
          })),
      ),
      ...coachGrammar,
    ];
    if (mode === "guided") pool = shuffle(guidedSet);
    else if (mode === "sentence") pool = shuffle(vocab);
    else if (mode === "coach") pool = shuffle(coachSet);
    else pool = [...pool, ...shuffle(vocab).slice(0, 3), ...shuffle(grammar)];
    if (!pool.length) pool = shuffle(GRAMMAR);
    setSession([...new Map(pool.map((e) => [e.id, e])).values()].slice(0, 5));
    setIndex(0);
    setAnswer("");
    setFeedback(null);
    setView("practice");
  }
  async function check() {
    if (!answer.trim() || !current) {
      notify("Сначала напишите или произнесите ответ");
      return;
    }
    keepListening.current = false;
    recognition.current?.stop();
    setListening(false);
    setChecking(true);
    try {
      const r = await fetch("/api/feedback", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          prompt: current.prompt,
          answer,
          modelAnswer: current.modelAnswer,
          requiredPhrase: current.requiredPhrase,
          topic: current.topic,
        }),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error();
      setFeedback(d);
      fetch("/api/attempts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          lessonId: current.lessonId,
          exerciseType: current.type,
          topic: current.topic,
          score: d.score,
        }),
      });
    } catch {
      notify("Не удалось проверить ответ");
    } finally {
      setChecking(false);
    }
  }
  const next = () => {
    keepListening.current = false;
    recognition.current?.stop();
    setListening(false);
    if (index < session.length - 1) {
      setIndex(index + 1);
      setAnswer("");
      setFeedback(null);
    } else {
      setSession([]);
      setAnswer("");
      setFeedback(null);
      reload();
      notify("Тренировка завершена");
    }
  };
  const exitPractice = () => {
    keepListening.current = false;
    recognition.current?.stop();
    setListening(false);
    setSession([]);
    setIndex(0);
    setAnswer("");
    setFeedback(null);
  };
  async function saveMistake() {
    if (!current || !feedback) return;
    const r = await fetch("/api/mistakes", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        lessonId: current.lessonId,
        prompt: current.prompt,
        userAnswer: answer,
        modelAnswer: feedback.naturalVersion || current.modelAnswer,
        tags: [current.topic],
        note: feedback.issues[0] || "",
      }),
    });
    if (r.ok) {
      await reload();
      notify("Добавлено в повторение");
      next();
    }
  }
  function speak() {
    const C =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!C) {
      notify("Распознавание речи не поддерживается этим браузером");
      return;
    }
    if (listening) {
      keepListening.current = false;
      recognition.current?.stop();
      setListening(false);
      return;
    }
    speechBase.current = answer.trim();
    speechCommitted.current = "";
    keepListening.current = true;
    setListening(true);
    const launch = () => {
      if (!keepListening.current) return;
      const r = new C();
      let cycleFinal = "";
      r.lang = "en-GB";
      r.interimResults = true;
      r.continuous = true;
      r.onresult = (e: any) => {
        let finalText = "", interimText = "";
        for (const result of Array.from(e.results) as any[]) {
          if (result.isFinal) finalText += `${result[0].transcript} `;
          else interimText += result[0].transcript;
        }
        cycleFinal = finalText.trim();
        setAnswer([speechBase.current, speechCommitted.current, cycleFinal, interimText].filter(Boolean).join(" ").replace(/\s+/g," "));
      };
      r.onerror = (e:any) => {
        if (["not-allowed","service-not-allowed","audio-capture"].includes(e.error)) {
          keepListening.current = false;
          setListening(false);
          notify("Проверьте доступ браузера к микрофону");
        }
      };
      r.onend = () => {
        if (cycleFinal) speechCommitted.current = [speechCommitted.current, cycleFinal].filter(Boolean).join(" ");
        if (keepListening.current) window.setTimeout(launch, 250);
        else setListening(false);
      };
      recognition.current = r;
      try { r.start(); } catch { if (keepListening.current) window.setTimeout(launch, 400); }
    };
    launch();
  }
  async function rate(q: string) {
    if (current?.mistakeId) {
      await fetch("/api/mistakes", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: current.mistakeId, quality: q }),
      });
      await reload();
    }
    next();
  }
  async function removeLesson(id: string) {
    if (!confirm("Удалить урок, его PDF и связанные ошибки?")) return;
    const r = await fetch(`/api/lessons?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
    if (r.ok) {
      const n = new Set(selected);
      n.delete(id);
      setSelected(n);
      await reload();
      notify("Урок удалён");
    }
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <button className="logo" onClick={() => setView("practice")}>
          <span>
            B<i>2</i>
          </span>
          <b>
            Between
            <br />
            the Lines
          </b>
        </button>
        <nav>
          <button
            className={view === "practice" ? "active" : ""}
            onClick={() => setView("practice")}
          >
            <Sparkles />
            Практика
          </button>
          <button
            className={view === "lessons" ? "active" : ""}
            onClick={() => setView("lessons")}
          >
            <Library />
            Уроки <em>{lessons.length}</em>
          </button>
          <button
            className={view === "grammar" ? "active" : ""}
            onClick={() => setView("grammar")}
          >
            <BookOpen />
            Грамматика
          </button>
          <button
            className={view === "review" ? "active" : ""}
            onClick={() => setView("review")}
          >
            <RefreshCw />
            Повторение {stats.due > 0 && <em>{stats.due}</em>}
          </button>
        </nav>
        <div className="streak">
          <Flame />
          <div>
            <b>
              {Math.min(
                7,
                new Set(attempts.map((a) => a.created_at?.slice(0, 10))).size,
              )}{" "}
              дней
            </b>
            <span>ритм занятий</span>
          </div>
        </div>
      </aside>
      <section className="content">
        <header className="mobile-header">
          <button className="logo">
            <span>
              B<i>2</i>
            </span>
          </button>
          <div>
            {(["practice", "lessons", "grammar", "review"] as const).map((v, i) => (
              <button
                key={v}
                className={view === v ? "active" : ""}
                onClick={() => setView(v)}
              >
                {["Практика", "Уроки", "Правила", "Повторить"][i]}
              </button>
            ))}
          </div>
        </header>
        {loading ? (
          <div className="loading">
            <LoaderCircle className="spin" />
            Загружаем ваши уроки…
          </div>
        ) : (
          <>
            {view === "practice" && (
              <Practice
                stats={stats}
                lessons={lessons}
                session={session}
                current={current}
                index={index}
                answer={answer}
                setAnswer={setAnswer}
                feedback={feedback}
                checking={checking}
                listening={listening}
                start={start}
                exit={exitPractice}
                check={check}
                speak={speak}
                next={next}
                save={saveMistake}
                rate={rate}
                openLessons={() => setView("lessons")}
                openCoach={() => setCoachSetup(true)}
              />
            )}{" "}
            {view === "lessons" && (
              <Lessons
                lessons={lessons}
                selected={selected}
                setSelected={setSelected}
                openUpload={() => setUpload(true)}
                practice={start}
                remove={removeLesson}
                study={setStudyLesson}
              />
            )}{" "}
            {view === "grammar" && <GrammarPage start={(topics) => start("coach", undefined, topics)} />}{" "}
            {view === "review" && (
              <Review
                mistakes={mistakes}
                lessons={lessons}
                practice={() => start("due")}
                reload={reload}
                notify={notify}
              />
            )}
          </>
        )}
      </section>
      {upload && (
        <UploadModal
          close={() => setUpload(false)}
          saved={async () => {
            setUpload(false);
            await reload();
            setView("lessons");
            notify("Урок добавлен в библиотеку");
          }}
          notify={notify}
        />
      )}{" "}
      {studyLesson && (
        <StudyModal
          lesson={studyLesson}
          close={() => setStudyLesson(null)}
          saved={async () => { await reload(); setStudyLesson(null); notify("Урок обновлён"); }}
          start={(mode) => {
            const ids = new Set([studyLesson.id]);
            setSelected(ids);
            setStudyLesson(null);
            start(mode, ids);
          }}
        />
      )}
      {coachSetup && <CoachSetup lessons={lessons} mistakes={mistakes} close={() => setCoachSetup(false)} start={(ids, topics) => { setCoachSetup(false); start("coach", ids, topics); }} />}
      <div className={`toast ${toast ? "show" : ""}`}>{toast}</div>
    </main>
  );
}

function Practice(p: any) {
  if (p.session.length && p.current)
    return (
      <div
        className={`exercise-screen ${p.current.type === "coach" ? "coach-screen" : ""}`}
      >
        <div className="exercise-top">
          <button className="back" onClick={p.exit}>
            <ChevronLeft />
            Выйти
          </button>
          <div className="session-progress">
            <div>
              <span
                style={{
                  width: `${((p.index + 1) / p.session.length) * 100}%`,
                }}
              />
            </div>
            <b>
              {p.index + 1} / {p.session.length}
            </b>
          </div>
        </div>
        <div className="exercise-wrap">
          <article className="exercise-card">
            <div className="pill-row">
              <span className="topic-pill">{p.current.topic}</span>
              <span className="type-pill">
                {p.current.type === "sentence"
                  ? "Своя фраза"
                  : p.current.type === "review"
                    ? "Повторение"
                    : p.current.type === "coach"
                      ? "English Coach"
                      : "Перевод"}
              </span>
            </div>
            <p className="kicker">
              {p.current.type === "translation"
                ? "Переведите естественно"
                : p.current.type === "review"
                  ? "Попробуйте ещё раз"
                  : p.current.type === "coach"
                    ? "Ответьте как в обычном разговоре"
                    : "Составьте свою фразу"}
            </p>
            <h1>{p.current.prompt}</h1>
            {p.current.targetWords?.length > 0 && (
              <div className="target-cues">
                <span>Постарайтесь использовать</span>
                {p.current.targetWords.map((w: string) => (
                  <b key={w}>{w}</b>
                ))}
              </div>
            )}
            <label>Ваш ответ</label>
            <div className={`answer-box ${p.listening ? "listening" : ""}`}>
              <textarea
                value={p.answer}
                onChange={(e: any) => p.setAnswer(e.target.value)}
                placeholder="Напишите или произнесите ответ…"
                disabled={!!p.feedback}
              />
              <button className="mic" onClick={p.speak} aria-label={p.listening?"Остановить запись":"Начать длительную запись"} title={p.listening?"Нажмите, чтобы остановить":"Буду слушать даже после пауз"}>
                <Mic />
                {p.listening && <span />}
              </button>
            </div>
            {p.listening && <p className="listening-note">Слушаю долго — можно делать паузы. Нажмите микрофон ещё раз, чтобы остановить.</p>}
            {!p.feedback ? (
              <button
                className="primary wide"
                onClick={p.check}
                disabled={p.checking}
              >
                {p.checking ? (
                  <>
                    <LoaderCircle className="spin" />
                    Проверяем…
                  </>
                ) : (
                  <>
                    Проверить ответ
                    <ArrowRight />
                  </>
                )}
              </button>
            ) : (
              <FeedbackCard
                data={p.feedback}
                model={p.current.modelAnswer}
                alt={p.current.alternative}
              />
            )}{" "}
            {p.feedback && (
              <div className="feedback-actions">
                <button className="secondary" onClick={p.save}>
                  <CircleAlert />
                  Сохранить ошибку
                </button>
                {p.current.type === "review" ? (
                  <div className="rating">
                    <span>Насколько легко?</span>
                    <button onClick={() => p.rate("again")}>Ещё раз</button>
                    <button onClick={() => p.rate("hard")}>Сложно</button>
                    <button onClick={() => p.rate("good")}>Хорошо</button>
                    <button onClick={() => p.rate("easy")}>Легко</button>
                  </div>
                ) : (
                  <button className="primary" onClick={p.next}>
                    {p.current.type === "coach"
                      ? "Продолжить разговор"
                      : "Дальше"}
                    <ChevronRight />
                  </button>
                )}
              </div>
            )}
          </article>
        </div>
      </div>
    );
  return (
    <div className="dashboard">
      <Title
        eyebrow="Adaptive English practice"
        title="Что потренируем сегодня?"
        subtitle="Новые фразы, материал ваших уроков и то, что пора повторить."
        action={
          p.lessons.length ? (
            <button
              className="secondary desktop-only"
              onClick={() => p.start("fresh")}
            >
              <RefreshCw />
              Свежий сет
            </button>
          ) : null
        }
      />
      <div className="hero-grid">
        <button
          className="start-card due"
          onClick={() => (p.stats.due ? p.start("due") : p.start("fresh"))}
        >
          <div className="start-icon">
            <Target />
          </div>
          <div>
            <span>
              {p.stats.due
                ? `${p.stats.due} заданий ждут вас`
                : "Начать разминку"}
            </span>
            <h2>
              {p.stats.due ? "Повторить на сегодня" : "Свежая B2-практика"}
            </h2>
            <p>
              {p.stats.due
                ? "Интервальное повторение ваших ошибок"
                : "Пять сложных предложений на главные темы"}
            </p>
          </div>
          <ArrowRight className="go" />
        </button>
        <button
          className="start-card lesson"
          onClick={p.lessons.length ? () => p.start("guided") : p.openLessons}
        >
          <div className="start-icon">
            <BookOpen />
          </div>
          <div>
            <span>
              {p.lessons.length
                ? `${p.lessons.length} уроков в библиотеке`
                : "Добавьте первый материал"}
            </span>
            <h2>{p.lessons.length ? "Практика по урокам" : "Загрузить PDF"}</h2>
            <p>Русские предложения со словами из занятий</p>
          </div>
          <ArrowRight className="go" />
        </button>
        <button className="start-card coach" onClick={p.openCoach}>
          <div className="start-icon">
            <Mic />
          </div>
          <div>
            <span>Speaking · Writing · Grammar</span>
            <h2>English Coach</h2>
            <p>Свободный чат по вашим урокам и частым ошибкам</p>
          </div>
          <ArrowRight className="go" />
        </button>
      </div>
      <div className="metric-grid">
        <Metric
          label="Средний результат"
          value={p.stats.avg ? `${p.stats.avg}%` : "—"}
          note="по последним попыткам"
        />
        <Metric
          label="Закреплено"
          value={p.stats.mastered}
          note="ошибок уже выучено"
        />
        <Metric
          label="Материалы"
          value={p.lessons.length}
          note="уроков в библиотеке"
        />
      </div>
      <div className="topic-strip">
        <div>
          <p className="eyebrow">Ваш постоянный фокус</p>
          <h3>Сложные темы всегда под рукой</h3>
        </div>
        {[
          "Conditionals",
          "Time clauses",
          "Modal verbs",
          "Past Simple vs Continuous",
          "Natural phrasing",
        ].map((t: string, i: number) => (
          <span key={t} className={`topic t${i}`}>
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}
function FeedbackCard({
  data,
  model,
  alt,
}: {
  data: Feedback;
  model: string;
  alt?: string;
}) {
  const ruleDetails = data.rules || [];
  return (
    <section className="feedback-panel">
      <div
        className="score-ring"
        style={{ "--score": `${data.score * 3.6}deg` } as React.CSSProperties}
      >
        <b>{data.score}</b>
        <span>/100</span>
      </div>
      <div className="feedback-copy">
        <div className="feedback-head">
          <span>{data.verdict}</span>
          <em>{data.source === "ai" ? "AI feedback" : "быстрая проверка"}</em>
        </div>
        {data.strengths.map((x) => (
          <p className="strength" key={x}>
            <Check />
            {x}
          </p>
        ))}
        {data.issues.map((x) => (
          <p className="issue" key={x}>
            <CircleAlert />
            {x}
          </p>
        ))}
        <div className="model-answer">
          <span>Естественный вариант</span>
          <p>{data.naturalVersion || model}</p>
          {alt && <small>Также: {alt}</small>}
          <button
            onClick={() =>
              speechSynthesis.speak(
                new SpeechSynthesisUtterance(data.naturalVersion || model),
              )
            }
          >
            <Volume2 />
            Прослушать
          </button>
        </div>
        <p className="explanation">{data.explanation}</p>
        {ruleDetails.length > 0 && (
          <details className="rule-breakdown" open>
            <summary>Разбор по частям: время, конструкция и причина</summary>
            {ruleDetails.map((r, i) => (
              <div key={`${r.label}-${i}`}>
                <span>{r.label}</span>
                <b>{r.fragment}</b>
                {r.formula && <code>{r.formula}</code>}
                <p>{r.explanation}</p>
              </div>
            ))}
          </details>
        )}
        <TutorQuestions sentence={data.naturalVersion || model} rules={ruleDetails} />
      </div>
    </section>
  );
}

function TutorQuestions({sentence,rules}:{sentence:string;rules:NonNullable<Feedback["rules"]>}){
  const [question,setQuestion]=useState(""),[messages,setMessages]=useState<Array<{question:string;answer:string}>>([]),[asking,setAsking]=useState(false);
  const ask=async()=>{if(!question.trim())return;setAsking(true);try{const r=await fetch("/api/question",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({question,sentence,rules})});const d:any=await r.json();if(!r.ok)throw Error();setMessages([...messages,{question,answer:d.answer}]);setQuestion("")}catch{setMessages([...messages,{question,answer:"Не удалось получить ответ. Попробуйте ещё раз."}])}finally{setAsking(false)}};
  return <section className="tutor-questions"><div><b>Осталось непонятно?</b><span>Спросите именно об этом предложении — например: «Почему здесь Present Perfect?»</span></div>{messages.map((m,i)=><div className="tutor-message" key={i}><p><b>Вы:</b> {m.question}</p><p><b>Разбор:</b> {m.answer}</p></div>)}<div className="question-box"><input value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")ask()}} placeholder="Почему здесь we've discussed?"/><button onClick={ask} disabled={asking||!question.trim()}>{asking?"…":"Спросить"}</button></div></section>
}
function Title({
  eyebrow,
  title,
  subtitle,
  action,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-title">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {action}
    </div>
  );
}
function Metric({
  label,
  value,
  note,
}: {
  label: string;
  value: string | number;
  note: string;
}) {
  return (
    <div>
      <span>{label}</span>
      <b>{value}</b>
      <small>{note}</small>
    </div>
  );
}

function Lessons({
  lessons,
  selected,
  setSelected,
  openUpload,
  practice,
  remove,
  study,
}: {
  lessons: Lesson[];
  selected: Set<string>;
  setSelected: (s: Set<string>) => void;
  openUpload: () => void;
  practice: (m: "guided" | "sentence") => void;
  remove: (id: string) => void;
  study: (l: Lesson) => void;
}) {
  const [q, setQ] = useState("");
  const shown = lessons.filter((l) =>
    `${l.title} ${l.topics}`.toLowerCase().includes(q.toLowerCase()),
  );
  const toggle = (id: string) => {
    const n = new Set(selected);
    n.has(id) ? n.delete(id) : n.add(id);
    setSelected(n);
  };
  return (
    <div>
      <Title
        eyebrow="Материалы занятий"
        title="Мои уроки"
        subtitle="Выбирайте один урок или смешивайте несколько."
        action={
          <button className="primary" onClick={openUpload}>
            <Plus />
            Загрузить PDF
          </button>
        }
      />
      {lessons.length ? (
        <>
          <div className="lesson-toolbar">
            <label>
              <Search />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Найти урок или тему"
              />
            </label>
            <span>
              Выбрано: <b>{selected.size}</b>
            </span>
          </div>
          <div className="mode-bar">
            <div>
              <b>Режим практики</b>
              <span>по выбранным урокам</span>
            </div>
            <button
              disabled={!selected.size}
              onClick={() => practice("guided")}
            >
              <FileText />
              <b>Русские предложения</b>
              <span>с подсказками-словами</span>
            </button>
            <button
              disabled={!selected.size}
              onClick={() => practice("sentence")}
            >
              <Sparkles />
              <b>Своя фраза</b>
              <span>по слову из урока</span>
            </button>
          </div>
          <div className="lesson-grid">
            {shown.map((l, i) => (
              <article
                className={`lesson-card ${selected.has(l.id) ? "selected" : ""}`}
                key={l.id}
                onClick={() => toggle(l.id)}
              >
                <div className={`file-icon c${i % 4}`}>
                  <FileText />
                </div>
                <div className="lesson-main">
                  <div>
                    <span>{formatDate(l.createdAt)}</span>
                    <button
                      className="more"
                      onClick={(e) => {
                        e.stopPropagation();
                        remove(l.id);
                      }}
                    >
                      <Trash2 />
                    </button>
                  </div>
                  <h2>{l.title}</h2>
                  <p>
                    {l.items.length} слов и выражений · {l.topics.length} тем
                  </p>
                  <div className="chips">
                    {l.topics.slice(0, 3).map((t) => (
                      <span key={t}>{t}</span>
                    ))}
                  </div>
                  <button
                    className="study-link"
                    onClick={(e) => {
                      e.stopPropagation();
                      study(l);
                    }}
                  >
                    <BookOpen />
                    Слова и правила
                  </button>
                </div>
                <div className="select-check">
                  {selected.has(l.id) && <Check />}
                </div>
              </article>
            ))}
          </div>
        </>
      ) : (
        <Empty upload={openUpload} />
      )}
    </div>
  );
}
function Empty({ upload }: { upload: () => void }) {
  return (
    <div className="empty">
      <div>
        <Upload />
      </div>
      <h2>Загрузите материал первого урока</h2>
      <p>
        Сайт найдёт слова и грамматические темы в PDF и подготовит упражнения.
      </p>
      <button className="primary" onClick={upload}>
        <Upload />
        Выбрать PDF
      </button>
    </div>
  );
}

function Review({
  mistakes,
  lessons,
  practice,
  reload,
  notify,
}: {
  mistakes: Mistake[];
  lessons: Lesson[];
  practice: () => void;
  reload: () => Promise<void>;
  notify: (s: string) => void;
}) {
  const active = mistakes.filter((m) => !m.mastered),
    due = active.filter(isDue),
    mastered = mistakes.filter((m) => m.mastered);
  const weakTopics = [...new Map(active.flatMap((m) => m.tags).map((tag) => [tag, active.filter((m) => m.tags.includes(tag)).length])).entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);
  const name = (id?: string) =>
    lessons.find((l) => l.id === id)?.title || "Общая практика";
  const patch = async (id: string, m: boolean) => {
    await fetch("/api/mistakes", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, mastered: m }),
    });
    await reload();
    notify(m ? "Отмечено как выученное" : "Возвращено в повторение");
  };
  return (
    <div>
      <Title
        eyebrow="Spaced repetition"
        title="Повторение"
        subtitle="Сайт возвращает сложные фразы в нужный момент."
        action={
          <button className="primary" onClick={practice} disabled={!due.length}>
            <RefreshCw />
            {due.length ? `Повторить сейчас · ${due.length}` : "На сегодня всё"}
          </button>
        }
      />
      <div className="review-stats">
        <Metric label="Сегодня" value={due.length} note="пора повторить" />
        <Metric
          label="Позже"
          value={active.length - due.length}
          note="уже запланировано"
        />
        <Metric
          label="Закреплено"
          value={mastered.length}
          note="можно вернуть"
        />
      </div>
      {weakTopics.length > 0 && (
        <section className="mistake-map">
          <div>
            <span>Карта ошибок</span>
            <b>Что возвращается чаще всего</b>
          </div>
          {weakTopics.map(([tag, count]) => (
            <span key={tag}>
              {tag} <b>{count}</b>
            </span>
          ))}
          <small>Эти темы получают приоритет в повторении и English Coach.</small>
        </section>
      )}
      {mistakes.length ? (
        <div className="review-list">
          {mistakes.map((m) => (
            <article
              className={`review-card ${m.mastered ? "mastered" : ""}`}
              key={m.id}
            >
              <div className="review-status">
                {m.mastered ? (
                  <Check />
                ) : isDue(m) ? (
                  <RefreshCw />
                ) : (
                  <span>
                    {Math.max(
                      1,
                      Math.ceil(
                        (new Date(m.nextReviewAt).getTime() - Date.now()) /
                          86400000,
                      ),
                    )}
                    д
                  </span>
                )}
              </div>
              <div>
                <span className="lesson-link">{name(m.lessonId)}</span>
                <h3>{m.prompt}</h3>
                <p className="wrong">{m.userAnswer}</p>
                <p className="right">{m.modelAnswer}</p>
                {m.note && <p className="mistake-note">Почему: {m.note}</p>}
                <div className="chips">
                  {m.tags.map((t) => (
                    <span key={t}>{t}</span>
                  ))}
                </div>
              </div>
              <button
                className="master"
                onClick={() => patch(m.id, !m.mastered)}
              >
                {m.mastered ? "Вернуть" : "Выучено"}
              </button>
            </article>
          ))}
        </div>
      ) : (
        <div className="empty slim">
          <div>
            <Check />
          </div>
          <h2>Пока нет сохранённых ошибок</h2>
          <p>Во время практики нажмите «Сохранить ошибку».</p>
        </div>
      )}
    </div>
  );
}

function GrammarPage({ start }: { start: (topics: Set<string>) => void }) {
  const [open, setOpen] = useState<string | null>("Conditionals");
  return <div><Title eyebrow="Grammar library" title="Грамматика" subtitle="Откройте тему, прочитайте правило и сразу потренируйте его." />
    <div className="grammar-grid">{Object.entries(RULES).filter(([topic])=>topic!=="Vocabulary").map(([topic,rules])=><article className={open===topic?"open":""} key={topic}>
      <button onClick={()=>setOpen(open===topic?null:topic)}><div><span>{rules.length} {rules.length===1?"правило":"правила"}</span><h2>{topic}</h2></div><ChevronRight/></button>
      {open===topic&&<div className="grammar-details">{rules.map(rule=><section key={rule.title}><h3>{rule.title}</h3><p>{rule.description}</p><b>{rule.example}</b><button onClick={()=>{const u=new SpeechSynthesisUtterance(rule.example);u.lang="en-GB";speechSynthesis.speak(u)}}><Volume2/> UK</button></section>)}<button className="primary" onClick={()=>start(new Set([topic]))}><Sparkles/>Тренировать эту тему</button></div>}
    </article>)}</div>
  </div>;
}

function CoachSetup({lessons,mistakes,close,start}:{lessons:Lesson[];mistakes:Mistake[];close:()=>void;start:(ids:Set<string>|undefined,topics:Set<string>)=>void}){
  const [lessonIds,setLessonIds]=useState<Set<string>>(new Set()),[topics,setTopics]=useState<Set<string>>(new Set());
  const toggle=(set:Set<string>,value:string,save:(s:Set<string>)=>void)=>{const n=new Set(set);n.has(value)?n.delete(value):n.add(value);save(n)};
  const grammarTopics=Object.keys(RULES).filter(t=>t!=="Vocabulary");
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><section className="modal coach-setup"><div className="modal-head"><div><p className="eyebrow">English Coach</p><h2>Что включить в разговор?</h2></div><button onClick={close}><X/></button></div>
    <p className="setup-copy">Можно выбрать несколько уроков и правил. Сохранённые ошибки добавляются автоматически.</p>
    <fieldset><legend>Мои уроки</legend><div className="choice-grid">{lessons.map(l=><button className={lessonIds.has(l.id)?"active":""} onClick={()=>toggle(lessonIds,l.id,setLessonIds)} key={l.id}><Check/>{l.title}</button>)}</div>{!lessons.length&&<small>Сначала загрузите PDF — пока будет общая практика.</small>}</fieldset>
    <fieldset><legend>Грамматика</legend><div className="choice-grid">{grammarTopics.map(t=><button className={topics.has(t)?"active":""} onClick={()=>toggle(topics,t,setTopics)} key={t}><Check/>{t}</button>)}</div></fieldset>
    <div className="coach-memory"><RefreshCw/><span><b>{mistakes.filter(m=>!m.mastered).length} сохранённых ошибок</b> будут подмешиваться в разговор, чтобы возвращать ваши слабые места.</span></div>
    <div className="modal-actions"><button className="secondary" onClick={close}>Отмена</button><button className="primary" onClick={()=>start(lessonIds.size?lessonIds:undefined,topics)}>Начать разговор<ArrowRight/></button></div>
  </section></div>;
}

function StudyModal({
  lesson,
  close,
  start,
  saved,
}: {
  lesson: Lesson;
  close: () => void;
  start: (mode: "guided" | "sentence") => void;
  saved: () => void;
}) {
  const [tab, setTab] = useState<"words" | "rules">("words"),
    [q, setQ] = useState(""),
    [title, setTitle] = useState(lesson.title),
    [items, setItems] = useState(lesson.items.map(addKnownHelp)),
    [saving, setSaving] = useState(false);
  const words = items.map((item,index)=>({item,index})).filter(({item:i}) =>
    `${i.term} ${i.meaning || ""} ${i.example || ""}`.toLowerCase().includes(q.toLowerCase()),
  );
  const rules = [
    ...new Map(
      lesson.topics
        .flatMap((t) =>
          (RULES[t] || RULES.Vocabulary).map(
            (r) => [`${t}-${r.title}`, { ...r, topic: t }] as const,
          ),
        ),
    ).values(),
  ];
  function play(text: string) {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-GB";
    u.rate = 0.86;
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  }
  const updateItem=(index:number,key:keyof LessonItem,value:string)=>setItems(items.map((item,i)=>i===index?{...item,[key]:value}:item));
  const save=async()=>{setSaving(true);try{const r=await fetch("/api/lessons",{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({id:lesson.id,title,topics:lesson.topics,items})});if(!r.ok)throw Error();saved()}finally{setSaving(false)}};
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <section className="modal study-modal">
        <div className="modal-head">
          <div>
            <p className="eyebrow">
              {formatDate(lesson.createdAt)} · материалы урока
            </p>
            <input className="lesson-title-input" value={title} onChange={(e)=>setTitle(e.target.value)} aria-label="Название урока" />
          </div>
          <button onClick={close}>
            <X />
          </button>
        </div>
        <div className="study-tabs">
          <button
            className={tab === "words" ? "active" : ""}
            onClick={() => setTab("words")}
          >
            Слова · {items.length}
          </button>
          <button
            className={tab === "rules" ? "active" : ""}
            onClick={() => setTab("rules")}
          >
            Правила · {rules.length}
          </button>
        </div>
        {tab === "words" ? (
          <>
            <div className="study-tools">
              <label>
                <Search />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Найти слово"
                />
              </label>
              <span className="british-badge">🇬🇧 British English</span>
            </div>
            <div className="word-list">
              {words.map(({item,index}) => (
                <div className="word-editor" key={`${item.term}-${index}`}>
                  <button onClick={() => play(item.term)}>
                    <Volume2 />
                  </button>
                  <div>
                    <b>{item.term}</b>
                    <input value={item.meaning||""} onChange={(e)=>updateItem(index,"meaning",e.target.value)} placeholder="Добавить перевод" />
                    <input value={item.example||""} onChange={(e)=>updateItem(index,"example",e.target.value)} placeholder="Добавить пример на английском" />
                    {item.example&&<button className="example-audio" onClick={()=>play(item.example!)}><Volume2/> пример</button>}
                    <small>{item.pronunciation||pronunciationTip(item.term)}</small>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="rules-list">
            {rules.map((rule, i) => (
              <article key={i}>
                <span>{rule.topic}</span>
                <h3>{rule.title}</h3>
                <p>{rule.description}</p>
                <div>
                  <b>{rule.example}</b>
                  <button onClick={() => play(rule.example)}>
                    <Volume2 />
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
        <div className="study-actions">
          <button className="secondary" disabled={saving||!title.trim()} onClick={save}>{saving?"Сохраняем…":"Сохранить изменения"}</button>
          <button className="secondary" onClick={() => start("sentence")}>
            <Sparkles />
            Своя фраза
          </button>
          <button className="primary" onClick={() => start("guided")}>
            <FileText />
            Перевести предложения
          </button>
        </div>
      </section>
    </div>
  );
}

function UploadModal({
  close,
  saved,
  notify,
}: {
  close: () => void;
  saved: () => void;
  notify: (s: string) => void;
}) {
  const [file, setFile] = useState<File | null>(null),
    [title, setTitle] = useState(""),
    [text, setText] = useState(""),
    [topics, setTopics] = useState<string[]>([]),
    [items, setItems] = useState<LessonItem[]>([]),
    [stage, setStage] = useState<"pick" | "review" | "saving">("pick");
  async function choose(f: File) {
    if (f.type !== "application/pdf") {
      notify("Выберите PDF-файл");
      return;
    }
    setFile(f);
    setTitle(f.name.replace(/\.pdf$/i, ""));
    setStage("saving");
    try {
      const content = await pdfText(f);
      if (!content.trim()) throw Error();
      const m = analyze(content);
      setText(content);
      setTopics(m.topics);
      setItems(m.items);
      setStage("review");
    } catch {
      setStage("pick");
      notify("Не удалось прочитать текст PDF");
    }
  }
  async function save() {
    if (!file) return;
    setStage("saving");
    try {
      const fr = await fetch("/api/files", {
        method: "POST",
        headers: {
          "content-type": "application/pdf",
          "x-file-name": encodeURIComponent(file.name),
        },
        body: file,
      });
      const fd: any = await fr.json();
      if (!fr.ok) throw Error();
      const lr = await fetch("/api/lessons", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          title,
          fileName: file.name,
          fileKey: fd.key,
          contentText: text,
          topics,
          items,
        }),
      });
      if (!lr.ok) throw Error();
      saved();
    } catch {
      setStage("review");
      notify("Не удалось сохранить урок");
    }
  }
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <section className="modal">
        <div className="modal-head">
          <div>
            <p className="eyebrow">Новый материал</p>
            <h2>{stage === "review" ? "Проверьте урок" : "Загрузить PDF"}</h2>
          </div>
          <button onClick={close}>
            <X />
          </button>
        </div>
        {stage === "pick" ? (
          <label className="dropzone">
            <input
              type="file"
              accept="application/pdf"
              onChange={(e) => e.target.files?.[0] && choose(e.target.files[0])}
            />
            <div>
              <Upload />
            </div>
            <h3>Перетащите PDF сюда</h3>
            <p>или нажмите, чтобы выбрать · до 15 МБ</p>
            <span>
              Текст будет извлечён для упражнений, а PDF сохранится в вашей
              приватной библиотеке.
            </span>
          </label>
        ) : stage === "saving" ? (
          <div className="processing">
            <LoaderCircle className="spin" />
            <h3>{text ? "Сохраняем урок…" : "Читаем материал…"}</h3>
            <p>Ищем слова, выражения и грамматические темы.</p>
          </div>
        ) : (
          <div className="review-upload">
            <label>
              Название урока
              <input value={title} onChange={(e) => setTitle(e.target.value)} />
            </label>
            <div>
              <span className="field-label">Найденные темы</span>
              <div className="editable-chips">
                {topics.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTopics(topics.filter((x) => x !== t))}
                  >
                    {t}
                    <X />
                  </button>
                ))}
                <button
                  className="add-topic"
                  onClick={() => {
                    const t = prompt("Название темы");
                    if (t) setTopics([...topics, t]);
                  }}
                >
                  <Plus />
                  Добавить
                </button>
              </div>
            </div>
            <div>
              <span className="field-label">
                Слова и выражения · {items.length}
              </span>
              <div className="word-preview">
                {items.slice(0, 18).map((it, i) => (
                  <span key={`${it.term}-${i}`}>
                    <b>{it.term}</b>
                    {it.meaning && <> — {it.meaning}</>}
                  </span>
                ))}
                {items.length > 18 && <em>ещё {items.length - 18}</em>}
              </div>
            </div>
            <div className="modal-actions">
              <button className="secondary" onClick={() => setStage("pick")}>
                Другой файл
              </button>
              <button
                className="primary"
                onClick={save}
                disabled={!title.trim()}
              >
                Создать урок
                <ArrowRight />
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
