import { getDb, getEnv, jsonError, userEmail } from "@/lib/storage";

export const runtime = "edge";

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const title = String(body.title || "").trim().slice(0, 100);
    const contentText = String(body.contentText || "").slice(0, 160000);
    const topics = Array.isArray(body.topics) ? body.topics.slice(0, 20) : [];
    const items = Array.isArray(body.items) ? body.items.slice(0, 300) : [];
    if (!title) return Response.json({ error: "Добавьте название урока" }, { status: 400 });
    const id = crypto.randomUUID();
    const db = await getDb();
    await db.prepare(`INSERT INTO lessons (id, user_email, title, file_key, file_name, content_text, topics_json, items_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(
        id, userEmail(request), title, body.fileKey || null, String(body.fileName || "").slice(0, 180),
        contentText, JSON.stringify(topics), JSON.stringify(items)
      ).run();
    return Response.json({ id }, { status: 201 });
  } catch (error) {
    return jsonError(error, "Не удалось создать урок");
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const id = String(body.id || "");
    const title = String(body.title || "").trim().slice(0, 100);
    const topics = Array.isArray(body.topics) ? body.topics.slice(0, 20) : [];
    const items = Array.isArray(body.items) ? body.items.slice(0, 300) : [];
    if (!id || !title) return Response.json({ error: "Укажите урок и название" }, { status: 400 });
    const db = await getDb();
    const result = await db.prepare(
      "UPDATE lessons SET title = ?, topics_json = ?, items_json = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_email = ?",
    ).bind(title, JSON.stringify(topics), JSON.stringify(items), id, userEmail(request)).run();
    if (!result.meta.changes) return new Response("Not found", { status: 404 });
    return Response.json({ ok: true });
  } catch (error) {
    return jsonError(error, "Не удалось обновить урок");
  }
}

export async function DELETE(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("id");
    if (!id) return Response.json({ error: "Урок не указан" }, { status: 400 });
    const db = await getDb();
    const email = userEmail(request);
    const row = await db.prepare("SELECT file_key FROM lessons WHERE id = ? AND user_email = ?").bind(id, email).first<{file_key?: string}>();
    await db.batch([
      db.prepare("DELETE FROM mistakes WHERE lesson_id = ? AND user_email = ?").bind(id, email),
      db.prepare("DELETE FROM attempts WHERE lesson_id = ? AND user_email = ?").bind(id, email),
      db.prepare("DELETE FROM lessons WHERE id = ? AND user_email = ?").bind(id, email)
    ]);
    if (row?.file_key) (await getEnv()).LESSON_FILES.delete(row.file_key);
    return Response.json({ ok: true });
  } catch (error) {
    return jsonError(error, "Не удалось удалить урок");
  }
}
