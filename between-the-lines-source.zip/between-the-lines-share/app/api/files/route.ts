import { getEnv, jsonError, userEmail } from "@/lib/storage";

export const runtime = "edge";

export async function POST(request: Request) {
  try {
    const type = request.headers.get("content-type") || "";
    const length = Number(request.headers.get("content-length") || 0);
    if (!type.includes("application/pdf")) return Response.json({ error: "Можно загрузить только PDF" }, { status: 415 });
    if (length > 15 * 1024 * 1024) return Response.json({ error: "PDF должен быть меньше 15 МБ" }, { status: 413 });
    const body = await request.arrayBuffer();
    if (!body.byteLength || body.byteLength > 15 * 1024 * 1024) return Response.json({ error: "PDF пустой или слишком большой" }, { status: 400 });
    const env = await getEnv();
    const key = `lessons/${crypto.randomUUID()}.pdf`;
    await env.LESSON_FILES.put(key, body, {
      httpMetadata: { contentType: "application/pdf" },
      customMetadata: { owner: userEmail(request), originalName: request.headers.get("x-file-name") || "lesson.pdf" }
    });
    return Response.json({ key });
  } catch (error) {
    return jsonError(error, "Не удалось сохранить PDF");
  }
}

export async function GET(request: Request) {
  try {
    const key = new URL(request.url).searchParams.get("key");
    if (!key) return Response.json({ error: "Файл не указан" }, { status: 400 });
    const env = await getEnv();
    const object = await env.LESSON_FILES.get(key);
    if (!object || object.customMetadata?.owner !== userEmail(request)) return new Response("Not found", { status: 404 });
    return new Response(object.body, { headers: { "content-type": "application/pdf", "content-disposition": `inline; filename="lesson.pdf"` } });
  } catch (error) {
    return jsonError(error, "Не удалось открыть PDF");
  }
}
