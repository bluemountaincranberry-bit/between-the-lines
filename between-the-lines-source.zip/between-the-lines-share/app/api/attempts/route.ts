import { getDb, jsonError, userEmail } from "@/lib/storage";

export const runtime = "edge";

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const db = await getDb();
    await db.prepare("INSERT INTO attempts (id, user_email, lesson_id, exercise_type, topic, score) VALUES (?, ?, ?, ?, ?, ?)").bind(
      crypto.randomUUID(), userEmail(request), body.lessonId || null, String(body.exerciseType || "translation"),
      String(body.topic || "General").slice(0, 80), Math.max(0, Math.min(100, Number(body.score) || 0))
    ).run();
    return Response.json({ ok: true }, { status: 201 });
  } catch (error) {
    return jsonError(error, "Не удалось сохранить результат");
  }
}
