import { getDb, jsonError, safeJson, userEmail } from "@/lib/storage";

export const runtime = "edge";

export async function GET(request: Request) {
  try {
    const db = await getDb();
    const email = userEmail(request);
    const [lessonResult, mistakeResult, attemptResult] = await Promise.all([
      db.prepare("SELECT * FROM lessons WHERE user_email = ? ORDER BY created_at DESC").bind(email).all(),
      db.prepare("SELECT * FROM mistakes WHERE user_email = ? ORDER BY mastered ASC, next_review_at ASC").bind(email).all(),
      db.prepare("SELECT topic, score, created_at FROM attempts WHERE user_email = ? ORDER BY created_at DESC LIMIT 250").bind(email).all()
    ]);

    const lessons = lessonResult.results.map((row) => ({
      id: row.id, title: row.title, fileKey: row.file_key, fileName: row.file_name,
      contentText: row.content_text, topics: safeJson(row.topics_json, []),
      items: safeJson(row.items_json, []), createdAt: row.created_at
    }));
    const mistakes = mistakeResult.results.map((row) => ({
      id: row.id, lessonId: row.lesson_id, prompt: row.prompt, userAnswer: row.user_answer,
      modelAnswer: row.model_answer, tags: safeJson(row.tags_json, []), note: row.note,
      intervalDays: row.interval_days, repetitions: row.repetitions, nextReviewAt: row.next_review_at,
      mastered: Boolean(row.mastered), createdAt: row.created_at
    }));

    return Response.json({ lessons, mistakes, attempts: attemptResult.results });
  } catch (error) {
    return jsonError(error, "Не удалось загрузить ваши уроки");
  }
}
