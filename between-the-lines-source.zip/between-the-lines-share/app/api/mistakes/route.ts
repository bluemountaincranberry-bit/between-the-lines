import { getDb, jsonError, userEmail } from "@/lib/storage";

export const runtime = "edge";

export async function POST(request: Request) {
  try {
    const body = await request.json() as Record<string, unknown>;
    const id = crypto.randomUUID();
    const due = new Date(Date.now() + 86400000).toISOString();
    const db = await getDb();
    await db.prepare(`INSERT INTO mistakes
      (id, user_email, lesson_id, prompt, user_answer, model_answer, tags_json, note, next_review_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
        id, userEmail(request), body.lessonId || null, String(body.prompt || "").slice(0, 1500),
        String(body.userAnswer || "").slice(0, 2000), String(body.modelAnswer || "").slice(0, 2000),
        JSON.stringify(Array.isArray(body.tags) ? body.tags.slice(0, 12) : []), String(body.note || "").slice(0, 300), due
      ).run();
    return Response.json({ id, nextReviewAt: due }, { status: 201 });
  } catch (error) {
    return jsonError(error, "Не удалось сохранить ошибку");
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json() as { id?: string; quality?: string; mastered?: boolean };
    if (!body.id) return Response.json({ error: "Ошибка не указана" }, { status: 400 });
    const db = await getDb();
    const email = userEmail(request);
    const current = await db.prepare("SELECT interval_days, repetitions FROM mistakes WHERE id = ? AND user_email = ?").bind(body.id, email).first<{interval_days: number; repetitions: number}>();
    if (!current) return new Response("Not found", { status: 404 });
    if (typeof body.mastered === "boolean") {
      await db.prepare("UPDATE mistakes SET mastered = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_email = ?").bind(body.mastered ? 1 : 0, body.id, email).run();
      return Response.json({ ok: true });
    }
    const factors: Record<string, number> = { again: 0, hard: 1.5, good: 2.3, easy: 3.5 };
    const factor = factors[body.quality || "good"] ?? 2.3;
    const interval = factor === 0 ? 1 : Math.max(body.quality === "easy" ? 7 : 2, Math.round(current.interval_days * factor));
    const next = new Date(Date.now() + interval * 86400000).toISOString();
    await db.prepare(`UPDATE mistakes SET interval_days = ?, repetitions = ?, next_review_at = ?,
      mastered = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_email = ?`).bind(
        interval, factor === 0 ? 0 : current.repetitions + 1, next, current.repetitions >= 3 && body.quality === "easy" ? 1 : 0, body.id, email
      ).run();
    return Response.json({ ok: true, interval, nextReviewAt: next });
  } catch (error) {
    return jsonError(error, "Не удалось обновить повторение");
  }
}

export async function DELETE(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("id");
    const db = await getDb();
    await db.prepare("DELETE FROM mistakes WHERE id = ? AND user_email = ?").bind(id, userEmail(request)).run();
    return Response.json({ ok: true });
  } catch (error) {
    return jsonError(error, "Не удалось удалить ошибку");
  }
}
