import { getEnv, jsonError } from "@/lib/storage";

export const runtime = "edge";

function localFeedback(
  answer: string,
  target: string,
  requiredPhrase?: string,
) {
  const normalized = answer.toLowerCase().replace(/[^a-z' ]/g, " ");
  const targetWords: string[] = Array.from(
    target.toLowerCase().match(/[a-z']+/g) || [],
  );
  const overlap = targetWords.filter(
    (word, index) =>
      word.length > 2 &&
      targetWords.indexOf(word) === index &&
      normalized.includes(word),
  ).length;
  const coverage = targetWords.length
    ? overlap /
      Math.max(1, new Set(targetWords.filter((w) => w.length > 2)).size)
    : 0.65;
  const phraseUsed =
    !requiredPhrase || normalized.includes(requiredPhrase.toLowerCase());
  const issues: string[] = [];
  if (!/^[A-Z]/.test(answer.trim()))
    issues.push("Начните предложение с заглавной буквы.");
  if (!phraseUsed)
    issues.push(`Попробуйте использовать выражение “${requiredPhrase}”.`);
  if (/\bif\b.*\bwill\b/i.test(answer))
    issues.push(
      "Проверьте: после if в обычном условном предложении обычно не ставят will.",
    );
  if (/\b(he|she|it)\s+(go|do|have|work|try)\b/i.test(answer))
    issues.push("Проверьте окончание -s после he/she/it в Present Simple.");
  const rules: Array<{ label: string; fragment: string; formula?: string; explanation: string }> = [];
  const subject = target.match(/^(I|you|he|she|it|we|they|[A-Z][a-z]+)/i)?.[1];
  if (subject) rules.push({
    label: "Подлежащее",
    fragment: subject,
    formula: "subject → verb → object",
    explanation: "Это тот, кто выполняет действие. В английском подлежащее обычно нужно называть явно и ставить перед сказуемым.",
  });
  if (/We won't make a final decision until we've discussed all the options/i.test(target)) {
    rules.push(
      { label:"Future Simple · отрицание", fragment:"won't make", formula:"will not + V1", explanation:"Речь о будущем решении. Won't — сокращение от will not, а после will используется начальная форма make без to." },
      { label:"Устойчивое сочетание", fragment:"make a final decision", formula:"make + a decision", explanation:"По-английски решение обычно make, а не take. Final стоит перед существительным и уточняет, что решение окончательное." },
      { label:"Союз времени", fragment:"until", formula:"main clause + until + time clause", explanation:"Until означает «пока не / до тех пор, пока». После него не ставим will, хотя действие относится к будущему." },
      { label:"Present Perfect", fragment:"we've discussed", formula:"we have + V3 (discussed)", explanation:"We've = we have. Present Perfect выбран, потому что важно завершить обсуждение всех вариантов до будущего решения. Здесь также возможно Present Simple — until we discuss all the options, но Present Perfect сильнее подчёркивает результат: всё уже будет обсуждено." },
      { label:"Дополнение", fragment:"all the options", formula:"all + the + plural noun", explanation:"Это то, что мы должны обсудить. The показывает конкретный известный набор вариантов, а all подчёркивает, что нужно рассмотреть каждый из них." },
    );
  }
  if (/if .*had .*would have/i.test(target))
    rules.push({
      label: "Third conditional",
      fragment: "if + had + V3 → would have + V3",
      formula: "if + Past Perfect, would have + V3",
      explanation:
        "Так говорят о прошлом, которое уже нельзя изменить, и о его воображаемом результате.",
    });
  if (/\b(as soon as|when|until|before|after)\b/i.test(target) && !/We won't make a final decision until we've discussed/i.test(target))
    rules.push({
      label: "Time clause",
      fragment:
        (target.match(/\b(as soon as|when|until|before|after)\b[^,.]*/i) ||
          [])[0] || "time clause",
      formula: "when / until / as soon as + Present Simple или Present Perfect",
      explanation:
        "После союза времени для будущего не используют will. Present Simple называет действие, а Present Perfect подчёркивает, что оно должно полностью завершиться до следующего действия.",
    });
  if (/\b(should|must|might|could|can't) have\b/i.test(target))
    rules.push({
      label: "Modal perfect",
      fragment:
        (target.match(/\b(should|must|might|could|can't) have [^,.]*/i) ||
          [])[0] || "modal + have + V3",
      explanation:
        "Modal + have + V3 выражает совет, предположение или сожаление о прошлом.",
      formula: "modal + have + V3",
    });
  if (/\b(was|were)\s+\w+ing\b.*\bwhen\b/i.test(target))
    rules.push({
      label: "Past Continuous + Past Simple",
      fragment: "was/were + -ing … when + Past Simple",
      formula: "Past Continuous + when + Past Simple",
      explanation:
        "Длительное действие создаёт фон, а короткое событие его прерывает.",
    });
  if (/\b(take a closer look|put .* off|make a decision)\b/i.test(target))
    rules.push({
      label: "Collocation",
      fragment:
        (target.match(/take a closer look|put .*? off|make a decision/i) ||
          [])[0] || "natural collocation",
      explanation:
        "Это устойчивое сочетание, которое носители воспринимают как одну естественную единицу.",
    });
  if (/\b(I'll|won't|I'd|don't|doesn't|can't|it's)\b/.test(target))
    rules.push({
      label: "Natural spoken form",
      fragment:
        (target.match(/\b(I'll|won't|I'd|don't|doesn't|can't|it's)\b/) ||
          [])[0] || "contraction",
      explanation:
        "Сокращённая форма обычно звучит естественнее в разговоре и обычной рабочей переписке.",
    });
  if (!rules.length)
    rules.push({
      label: "Natural word order",
      fragment: target,
      explanation:
        "Английское предложение строится вокруг прямого порядка: подлежащее, сказуемое, дополнение и затем обстоятельства.",
    });
  return {
    source: "local",
    score: Math.max(
      35,
      Math.min(96, Math.round(coverage * 80 + (phraseUsed ? 16 : 0))),
    ),
    verdict:
      coverage > 0.72 && phraseUsed
        ? "Смысл передан хорошо"
        : "Есть что улучшить",
    strengths: phraseUsed
      ? ["Вы использовали нужную конструкцию."]
      : ["Вы сформулировали полный самостоятельный ответ."],
    issues: issues.length
      ? issues
      : ["Сравните порядок слов и выбор времени с модельным вариантом."],
    naturalVersion: target,
    explanation:
      "Сравните не отдельные слова, а всю конструкцию и устойчивые сочетания.",
    rules,
  };
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      prompt?: string;
      answer?: string;
      modelAnswer?: string;
      requiredPhrase?: string;
      topic?: string;
    };
    const answer = String(body.answer || "").trim();
    const modelAnswer = String(body.modelAnswer || "").trim();
    if (!answer)
      return Response.json({ error: "Введите ответ" }, { status: 400 });
    const env = await getEnv();
    if (!env.OPENAI_API_KEY)
      return Response.json(
        localFeedback(answer, modelAnswer, body.requiredPhrase),
      );

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: env.OPENAI_MODEL || "gpt-5-mini",
        input: [
          {
            role: "system",
            content:
              "You are a B2 English tutor for a Russian-speaking adult. Evaluate meaning, grammar, vocabulary and naturalness. Never mention or penalize missing final punctuation. Accept valid alternatives. Explain every meaningful part of the natural sentence, not only the main rule. For each part name the tense or construction, give its formula, expand contractions, explain why it is used here, and mention a valid alternative if useful. Return only JSON with score (0-100), verdict in Russian, strengths (array, max 2), issues (array, max 3), naturalVersion in English, explanation in Russian (max 3 sentences), and rules (array of 3-8 objects with label, exact fragment, formula, and a clear detailed Russian explanation).",
          },
          { role: "user", content: JSON.stringify(body) },
        ],
        text: {
          format: {
            type: "json_schema",
            name: "feedback",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              required: [
                "score",
                "verdict",
                "strengths",
                "issues",
                "naturalVersion",
                "explanation",
                "rules",
              ],
              properties: {
                score: { type: "number" },
                verdict: { type: "string" },
                strengths: { type: "array", items: { type: "string" } },
                issues: { type: "array", items: { type: "string" } },
                naturalVersion: { type: "string" },
                explanation: { type: "string" },
                rules: {
                  type: "array",
                  items: {
                    type: "object",
                    additionalProperties: false,
                    required: ["label", "fragment", "formula", "explanation"],
                    properties: {
                      label: { type: "string" },
                      fragment: { type: "string" },
                      formula: { type: "string" },
                      explanation: { type: "string" },
                    },
                  },
                },
              },
            },
          },
        },
      }),
    });
    if (!response.ok)
      return Response.json(
        localFeedback(answer, modelAnswer, body.requiredPhrase),
      );
    const data = (await response.json()) as { output_text?: string };
    const parsed = JSON.parse(data.output_text || "{}");
    return Response.json({ ...parsed, source: "ai" });
  } catch (error) {
    return jsonError(error, "Не удалось проверить ответ");
  }
}
