import { getEnv, jsonError } from "@/lib/storage";

export const runtime = "edge";

function localAnswer(question:string,sentence:string){
  const q=question.toLowerCase();
  if (/we['’]?ve|present perfect|have discussed/.test(q)) return "We've discussed — это we have discussed, то есть Present Perfect: have + V3. Discussed — третья форма правильного глагола discuss. Здесь важно, чтобы обсуждение всех вариантов было полностью завершено до будущего решения. Поэтому Present Perfect подчёркивает результат. Вариант until we discuss all the options тоже возможен, но он просто называет действие и слабее подчёркивает его завершённость.";
  if (/until|пока/.test(q)) return "Until означает «до тех пор, пока / пока не». В придаточной части после until не нужен will, даже когда речь о будущем: will остаётся в главной части, а после until используется Present Simple или Present Perfect.";
  if (/won['’]?t|will not|future/.test(q)) return "Won't — сокращённая форма will not. Это отрицательный Future Simple: subject + will not + V1. Поэтому после won't стоит make, а не made и не to make.";
  if (/make.*decision|decision/.test(q)) return "Make a decision — устойчивое сочетание «принять решение». В британском английском take a decision иногда встречается, особенно официально, но make a decision нейтральнее и гораздо универсальнее.";
  return `В предложении “${sentence}” сначала найдите сказуемое и вспомогательный глагол: именно они показывают время. Затем посмотрите на союз и связь между действиями. Если уточните фрагмент — например, “почему have + discussed?” — я смогу объяснить его точнее.`;
}

export async function POST(request:Request){
  try{
    const body=await request.json() as {question?:string;sentence?:string;rules?:unknown};
    const question=String(body.question||"").trim(),sentence=String(body.sentence||"").trim();
    if(!question)return Response.json({error:"Введите вопрос"},{status:400});
    const env=await getEnv();
    if(!env.OPENAI_API_KEY)return Response.json({answer:localAnswer(question,sentence),source:"local"});
    const response=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"content-type":"application/json",authorization:`Bearer ${env.OPENAI_API_KEY}`},body:JSON.stringify({model:env.OPENAI_MODEL||"gpt-5-mini",input:[{role:"system",content:"You are a patient English tutor for a Russian-speaking B2 learner. Answer the follow-up question in clear Russian. Explain the exact fragment, name the tense or construction, show its formula, expand contractions, explain why it fits this context, and mention useful alternatives. Be detailed but concise."},{role:"user",content:JSON.stringify(body)}]})});
    if(!response.ok)return Response.json({answer:localAnswer(question,sentence),source:"local"});
    const data=await response.json() as {output_text?:string};
    return Response.json({answer:data.output_text||localAnswer(question,sentence),source:"ai"});
  }catch(error){return jsonError(error,"Не удалось ответить на вопрос")}
}
