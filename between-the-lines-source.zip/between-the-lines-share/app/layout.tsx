import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Between the Lines — B2 English Practice",
  description: "Private adaptive English practice from your own lessons.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
