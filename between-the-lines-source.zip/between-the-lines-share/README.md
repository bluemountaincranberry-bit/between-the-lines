# Between the Lines

Reusable source for a private B2 English practice Site.

This copy contains no lessons, PDFs, answers, mistakes, credentials, database contents, or original Sites project ID.

## For a new owner and their agent

1. Create a new private Site in the new owner's account.
2. Let Sites assign a new `project_id`; never reuse Victoria's project.
3. Keep the logical D1 binding `DB` and R2 binding `LESSON_FILES`.
4. Install dependencies, build, and validate the main workflows.
5. Deploy privately and return the new URL.
6. Keep all future changes limited to the new owner's repository and Site.

If AI feedback and open-ended tutor chat are required, add `OPENAI_API_KEY` through Sites secrets. Never commit secrets to GitHub.
